<?php
// Votre logique côté serveur pour la configuration de l'authentification à deux facteurs ici
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="styles.css">
    <title>Configurer l'Authentification à Deux Facteurs</title>
</head>
<body>
    <div class="container">
        <h1>Configurer l'Authentification à Deux Facteurs</h1>
        <p>Page de configuration de l'authentification à deux facteurs.</p>
    </div>
</body>
</html>
