<?php
// Votre logique d'inscription côté serveur ici
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // ... Traitement du formulaire ...
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="styles.css">
    <title>Inscription</title>
</head>
<body>
    <div class="container">
        <h1>Inscription</h1>
        <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
            <label for="newUsername">Numéro d'étudiant :</label>
            <input type="text" id="newUsername" name="newUsername" required>

            <label for="newPassword">Mot de passe :</label>
            <input type="password" id="newPassword" name="newPassword" required>

            <button type="submit">S'inscrire</button>
        </form>
        <p>Vous avez déjà un compte ? <a href="connexion.php">Connectez-vous ici</a>.</p>
    </div>
</body>
</html>
